<?php
/** 
 * Simplr Registration Form Class
 * @package simple-registration-form
 * @since 2.2.3
 * @todo Slowly migrate function to this object
**/
if( !class_exists("Sreg_Submit") ) :

	class Sreg_Submit {
		public $errors;
		public $success;		

		public function __construct() {}	

	}

endif;
