<?php

function get_template_id(){
	return 0;
}
function setup_template_id($template_id){
	global $defblog_settings;
	$defblog_settings['act_template_id']=0;	
}

?>