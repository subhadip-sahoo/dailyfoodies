<?php /*
Plugin Name: Multisite Widgets
Plugin URI: http://muwidgets.dcoda.co.uk/
Description: Extends the standard WordPress widgets to be able to run on another blog on the site.
Author: dcoda
Author URI:
Version: 1.2.48f
License: GPLv2
*/
@require_once  dirname ( __FILE__ ) . '/library/wordpress/application.php';
new wv48fv_application ( __FILE__);
